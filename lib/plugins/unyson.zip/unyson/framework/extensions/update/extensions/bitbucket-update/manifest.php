<?php defined( 'FW' ) or die();

$manifest = array();

$manifest['standalone'] = true;
